# AI Forex Pro v1.1 Android UI prototype

## Included screens
- Home dashboard
- Forex market watch (placeholder rows)
- Crypto market watch (CoinDCX integration placeholder)
- Hindi-first AI Assistant demo chat
- Profile, security and risk-control information

## Open in Android Studio
1. Extract the ZIP.
2. Open the extracted project folder in Android Studio.
3. Allow Gradle sync and run on an Android device/emulator.

## Important
This is a UI prototype only. It does not contain live market data, AI backend, CoinDCX API, forex broker integration, or real order execution. Prices/market rows are illustrative placeholders.
Never embed API keys, exchange secrets, or broker passwords in the Android app. Use a secure backend and official provider authorization flows.

For Indian users, forex products and platforms must be reviewed for FEMA/RBI compliance and permitted exchange/broker access before enabling live orders. Crypto services also require applicable legal, tax, security and provider-policy review.

Before Play Store release, configure app signing, a unique package ID, privacy policy, data safety declarations, support details, screenshots, and current Play Console requirements.
