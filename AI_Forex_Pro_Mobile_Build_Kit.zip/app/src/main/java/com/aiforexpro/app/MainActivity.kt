package com.aiforexpro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF090F1B)
private val Panel = Color(0xFF121D2D)
private val Muted = Color(0xFF8FA1B8)
private val Blue = Color(0xFF5B9DFF)
private val Green = Color(0xFF20C997)
private val Red = Color(0xFFFF647C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ForexProApp() }
    }
}

@Composable
fun ForexProApp() {
    var tab by remember { mutableIntStateOf(0) }
    var showNotice by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    val labels = listOf("Home", "Forex", "Crypto", "AI Help", "Profile")
                    val icons = listOf(Icons.Default.Home, Icons.Default.ShowChart,
                        Icons.Default.CurrencyBitcoin, Icons.Default.SmartToy, Icons.Default.Person)
                    labels.forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i, onClick = { tab = i },
                            icon = { Icon(icons[i], contentDescription = label) },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Blue, selectedTextColor = Blue,
                                indicatorColor = Color(0xFF203553),
                                unselectedIconColor = Muted, unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(padding) { showNotice = true }
                1 -> MarketScreen(padding, "FOREX", listOf(
                    Triple("EUR/USD", "Illustrative quote", "+0.18%"),
                    Triple("GBP/USD", "Illustrative quote", "-0.12%"),
                    Triple("USD/JPY", "Illustrative quote", "+0.31%"),
                    Triple("USD/INR", "Currency pair • feed required", "—")
                )) { showNotice = true }
                2 -> MarketScreen(padding, "CRYPTO • COINDCX", listOf(
                    Triple("BTC/INR", "Illustrative quote", "+0.42%"),
                    Triple("ETH/INR", "Illustrative quote", "+0.25%"),
                    Triple("SOL/INR", "Illustrative quote", "-0.36%")
                )) { showNotice = true }
                3 -> AssistantScreen(padding)
                else -> ProfileScreen(padding) { showNotice = true }
            }
        }
        if (showNotice) {
            AlertDialog(
                onDismissRequest = { showNotice = false },
                title = { Text("Integration not connected") },
                text = { Text("This is a UI prototype. Live prices, AI responses and real orders need secure server-side integrations, approved provider access, account authorization and compliance checks. Do not enter broker passwords or API secrets here.") },
                confirmButton = { TextButton(onClick = { showNotice = false }) { Text("OK") } },
                containerColor = Panel, titleContentColor = Color.White, textContentColor = Muted
            )
        }
    }
}

@Composable
fun PageColumn(padding: PaddingValues, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp), content = content)
}

@Composable
fun HomeScreen(padding: PaddingValues, onConnect: () -> Unit) {
    PageColumn(padding) {
        Text("AI FOREX PRO", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text("One workspace for Forex, Crypto & AI assistance", color = Muted, fontSize = 12.sp)
        Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("ACCOUNT OVERVIEW", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("Connect your trading account", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.SemiBold)
                Text("Your real balance and positions will appear after secure provider integration.", color = Muted, fontSize = 12.sp)
                Button(onClick = onConnect, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Link, null); Spacer(Modifier.width(8.dp)); Text("Connect provider")
                }
                Text("Not connected • Preview mode", color = Color(0xFFFFC857), fontSize = 11.sp)
            }
        }
        Text("CHOOSE YOUR MARKET", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        FeatureCard("Forex", "Permitted Indian currency derivatives + chart analysis", Icons.Default.ShowChart)
        FeatureCard("Crypto", "CoinDCX account connection and crypto portfolio", Icons.Default.CurrencyBitcoin)
        FeatureCard("AI Assistant", "Hindi help, chart explanation and risk education", Icons.Default.SmartToy)
        Text("Prices and signals are not live in this prototype.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun FeatureCard(title: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(28.dp))
            Spacer(Modifier.width(12.dp))
            Column {
                Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(desc, color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun MarketScreen(padding: PaddingValues, title: String, rows: List<Triple<String,String,String>>, onTrade: () -> Unit) {
    PageColumn(padding) {
        Text(title, color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("Market watch • Sample layout, not live market data", color = Muted, fontSize = 11.sp)
        rows.forEach { (symbol, subtitle, change) ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(symbol, color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(subtitle, color = Muted, fontSize = 10.sp)
                    }
                    Text(change, color = if (change.startsWith("-")) Red else Green, fontSize = 12.sp)
                }
            }
        }
        Button(onClick = onTrade, modifier = Modifier.fillMaxWidth()) { Text("Connect account to enable trading") }
        Text("Forex availability depends on Indian regulatory permissions and the authorized exchange/broker.", color = Muted, fontSize = 11.sp)
    }
}

@Composable
fun AssistantScreen(padding: PaddingValues) {
    var question by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf(listOf("नमस्ते! मैं AI Forex Pro Assistant हूँ। आप Forex, Crypto, Chart और Risk Management के बारे में हिंदी में पूछ सकते हैं। अभी यह demo chat है।")) }
    PageColumn(padding) {
        Text("AI ASSISTANT", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text("Hindi-first trading help", color = Muted, fontSize = 12.sp)
        Card(Modifier.weight(1f, fill = true), colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
            LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                items(messages) { msg ->
                    Surface(color = Color(0xFF1B2B40), shape = RoundedCornerShape(12.dp)) {
                        Text(msg, Modifier.padding(12.dp), color = Color.White, fontSize = 13.sp)
                    }
                }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = question, onValueChange = { question = it },
                modifier = Modifier.weight(1f), placeholder = { Text("अपना सवाल लिखें…") },
                singleLine = true
            )
            Spacer(Modifier.width(8.dp))
            IconButton(onClick = {
                if (question.isNotBlank()) {
                    messages = messages + "आप: $question" + "Demo: AI backend जुड़ने के बाद मैं आपके सवाल का विश्लेषण कर पाऊँगा। अभी यह केवल UI preview है।"
                    question = ""
                }
            }) { Icon(Icons.Default.Send, contentDescription = "Send", tint = Blue) }
        }
        Text("AI उत्तर शिक्षा और विश्लेषण के लिए होंगे; लाभ की गारंटी या स्वतः ट्रेड निष्पादन नहीं।", color = Muted, fontSize = 10.sp)
    }
}

@Composable
fun ProfileScreen(padding: PaddingValues, onSettings: () -> Unit) {
    PageColumn(padding) {
        Text("PROFILE & SETTINGS", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        FeatureCard("Account security", "Provider login will use approved secure authorization.", Icons.Default.Lock)
        FeatureCard("Language", "Hindi + English", Icons.Default.Language)
        FeatureCard("Risk controls", "Order limits, confirmation and stop-loss checks", Icons.Default.Security)
        Button(onClick = onSettings, modifier = Modifier.fillMaxWidth()) { Text("Integration status") }
        Text("No credentials are stored in this starter app.", color = Muted, fontSize = 11.sp)
    }
}
