# AI Forex Pro v1.1 Android UI prototype

## Included screens
- Home dashboard
- Forex market watch (placeholder rows)
- Crypto market watch (CoinDCX integration placeholder)
- Hindi-first AI Assistant demo chat
- Profile, security and risk-control information

## Open in Android Studio
1. Extract the ZIP.
2. Open the extracted project folder in Android Studio.
3. Allow Gradle sync and run on an Android device/emulator.

## Important
This is a UI prototype only. It does not contain live market data, AI backend, CoinDCX API, forex broker integration, or real order execution. Prices/market rows are illustrative placeholders.
Never embed API keys, exchange secrets, or broker passwords in the Android app. Use a secure backend and official provider authorization flows.

For Indian users, forex products and platforms must be reviewed for FEMA/RBI compliance and permitted exchange/broker access before enabling live orders. Crypto services also require applicable legal, tax, security and provider-policy review.

Before Play Store release, configure app signing, a unique package ID, privacy policy, data safety declarations, support details, screenshots, and current Play Console requirements.


## Build from a mobile phone using GitHub Actions
1. Create/sign in to a GitHub account in your phone browser.
2. Create a new **private** repository named `ai-forex-pro`.
3. Extract this ZIP using a file manager that supports ZIP extraction.
4. Upload the extracted project files and folders (including the hidden `.github` folder) to the repository root. If the mobile upload UI hides `.github`, use GitHub's web editor to create `.github/workflows/android-build.yml` and paste the workflow from this project.
5. Open the repository's **Actions** tab and run **Build AI Forex Pro APK** (or push to `main`).
6. When the workflow succeeds, open the run, find **Artifacts**, and download `AI-Forex-Pro-debug-APK`. Extract the APK and install it on your own Android phone after allowing installs from that source.

This creates a debug APK for personal testing only. It is not a Play Store release build. A Play Store release needs a properly signed Android App Bundle, app signing key management, privacy/data-safety disclosures, policy review, and testing. Never upload signing keys or exchange API secrets into public source code.
