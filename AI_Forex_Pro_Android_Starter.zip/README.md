# AI Forex Pro — Android starter

This is a Kotlin + Jetpack Compose Android Studio starter UI for AI Forex Pro.

## Open
1. Install Android Studio.
2. Choose **Open** and select this project folder.
3. Allow Gradle sync.
4. Run on an Android device or emulator.

## Important current limitations
- This is a UI prototype, not a live trading terminal.
- Market prices shown are illustrative placeholders, not live prices.
- BUY/SELL and MT5 connect actions are intentionally disabled behind an information dialog.
- Real MT5 trading requires a broker-approved API/bridge, secure server-side order execution, authentication, audit logs, position/risk limits, and testing.
- Do not put MT5 passwords, API secrets, or broker credentials in the Android app source.
- Before offering forex trading to users in India, obtain legal/regulatory advice and verify that the broker, instruments, and electronic platform are permitted for Indian residents under FEMA/RBI requirements.

## Package
`com.aiforexpro.app`

Before Play Store release, configure a unique package ID, app signing, privacy policy, data safety declarations, support contact, screenshots, and current Google Play target SDK requirements.
