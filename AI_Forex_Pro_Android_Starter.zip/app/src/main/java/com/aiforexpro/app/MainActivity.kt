package com.aiforexpro.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Navy = Color(0xFF090F1B)
private val Panel = Color(0xFF121D2D)
private val Muted = Color(0xFF8FA1B8)
private val Green = Color(0xFF20C997)
private val Red = Color(0xFFFF647C)
private val Blue = Color(0xFF5B9DFF)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ForexApp() }
    }
}

@Composable
fun ForexApp() {
    var tab by remember { mutableStateOf(0) }
    var showInfo by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme(
        background = Navy, surface = Panel, primary = Blue,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Navy,
            bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Color.White) {
                    listOf("Home", "Markets", "Trade", "History", "Profile").forEachIndexed { i, label ->
                        NavigationBarItem(
                            selected = tab == i,
                            onClick = { tab = i },
                            icon = {
                                Icon(
                                    when (i) {
                                        0 -> Icons.Default.Home
                                        1 -> Icons.Default.ShowChart
                                        2 -> Icons.Default.SwapHoriz
                                        3 -> Icons.Default.History
                                        else -> Icons.Default.Person
                                    }, contentDescription = label
                                )
                            },
                            label = { Text(label, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = Blue,
                                selectedTextColor = Blue,
                                indicatorColor = Color(0xFF203553),
                                unselectedIconColor = Muted,
                                unselectedTextColor = Muted
                            )
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                item {
                    Row(Modifier.fillMaxWidth().padding(top = 18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column {
                            Text("AI FOREX PRO", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("Smart trading workspace", color = Muted, fontSize = 12.sp)
                        }
                        IconButton(onClick = { showInfo = true }) {
                            Icon(Icons.Default.Info, contentDescription = "Info", tint = Muted)
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(18.dp)) {
                            Text("ACCOUNT OVERVIEW", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(10.dp))
                            Text("Connect your MT5 account", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.SemiBold)
                            Text("Live balance will appear after secure broker integration.", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(14.dp))
                            Button(onClick = { showInfo = true }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Blue)) {
                                Icon(Icons.Default.Link, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Connect MT5")
                            }
                            Text("Not connected • Demo interface", color = Color(0xFFFFC857), fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Text("MARKET WATCH", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Column(verticalArrangement = Arrangement.spacedBy(9.dp)) {
                        MarketRow("EUR/USD", "1.08425", "+0.18%", true)
                        MarketRow("GBP/USD", "1.27180", "-0.12%", false)
                        MarketRow("USD/JPY", "149.620", "+0.31%", true)
                        MarketRow("XAU/USD", "2,638.40", "+0.42%", true)
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Blue)
                                Spacer(Modifier.width(8.dp))
                                Text("AI MARKET INSIGHT", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                Spacer(Modifier.weight(1f))
                                AssistChip(onClick = {}, label = { Text("Preview") })
                            }
                            Spacer(Modifier.height(8.dp))
                            Text("AI analysis will be available after connecting a verified market-data feed.", color = Muted, fontSize = 13.sp)
                            Spacer(Modifier.height(10.dp))
                            Text("No live signal • No trade recommendation", color = Color(0xFFFFC857), fontSize = 11.sp)
                        }
                    }
                }
                item {
                    Text("QUICK TRADE", color = Muted, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { showInfo = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Green)) {
                            Text("BUY", color = Navy, fontWeight = FontWeight.Bold)
                        }
                        Button(onClick = { showInfo = true }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Red)) {
                            Text("SELL", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                    Text("Trading is disabled until broker API, regulatory checks and risk controls are configured.", color = Muted, fontSize = 11.sp)
                    Spacer(Modifier.height(12.dp))
                }
            }
        }
        if (showInfo) {
            AlertDialog(
                onDismissRequest = { showInfo = false },
                title = { Text("MT5 connection required") },
                text = { Text("This starter app is a working UI prototype only. Real orders require a broker-approved API or bridge, secure backend, account permissions and regulatory review. Never share your MT5 password in chat.") },
                confirmButton = { TextButton(onClick = { showInfo = false }) { Text("OK") } },
                containerColor = Panel,
                titleContentColor = Color.White,
                textContentColor = Muted
            )
        }
    }
}

@Composable
fun MarketRow(pair: String, price: String, change: String, up: Boolean) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(14.dp)) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 15.dp, vertical = 13.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(pair, color = Color.White, fontWeight = FontWeight.SemiBold)
                Text("Forex market", color = Muted, fontSize = 10.sp)
            }
            Text(price, color = Color.White, fontWeight = FontWeight.Medium)
            Spacer(Modifier.width(12.dp))
            Text(change, color = if (up) Green else Red, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
    }
}
